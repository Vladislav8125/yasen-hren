import { NextResponse } from "next/server";

export function GET() {
  return NextResponse.redirect("https://yasenhren.ru/", 308);
}
