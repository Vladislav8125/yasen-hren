CREATE TYPE "PlatformAccessKind" AS ENUM ('PRIMARY', 'ADDON', 'LEGACY', 'TRIAL');
CREATE TYPE "PaymentPurpose" AS ENUM ('PRIMARY_SUBSCRIPTION', 'PLATFORM_ADDON');

ALTER TABLE "User" ADD COLUMN "legacyAllPlatforms" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "Payment" ADD COLUMN "channel" "DeliveryChannel";
ALTER TABLE "Payment" ADD COLUMN "purpose" "PaymentPurpose" NOT NULL DEFAULT 'PRIMARY_SUBSCRIPTION';
ALTER TABLE "Payment" ADD COLUMN "accessExpiresAt" TIMESTAMP(3);
ALTER TABLE "PublicShopOrder" ADD COLUMN "sourceChannel" "DeliveryChannel";
ALTER TABLE "PublicShopOrder" ADD COLUMN "sourceExternalId" TEXT;
ALTER TABLE "PublicShopOrder" ADD COLUMN "deliveryMethod" TEXT;

CREATE TABLE "PlatformEntitlement" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "channel" "DeliveryChannel" NOT NULL,
  "tariff" "Tariff" NOT NULL,
  "kind" "PlatformAccessKind" NOT NULL,
  "startsAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "expiresAt" TIMESTAMP(3),
  "autoRenew" BOOLEAN NOT NULL DEFAULT false,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "PlatformEntitlement_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "PlatformEntitlement_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE UNIQUE INDEX "PlatformEntitlement_userId_channel_kind_key" ON "PlatformEntitlement"("userId", "channel", "kind");
CREATE INDEX "PlatformEntitlement_userId_channel_expiresAt_idx" ON "PlatformEntitlement"("userId", "channel", "expiresAt");

CREATE TABLE "PlatformSubscription" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "channel" "DeliveryChannel" NOT NULL,
  "tariff" "Tariff" NOT NULL,
  "status" "SubscriptionStatus" NOT NULL DEFAULT 'ACTIVE',
  "initialInvoiceId" TEXT NOT NULL,
  "lastInvoiceId" TEXT,
  "lastPaymentAt" TIMESTAMP(3),
  "nextChargeAt" TIMESTAMP(3) NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "PlatformSubscription_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "PlatformSubscription_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE UNIQUE INDEX "PlatformSubscription_initialInvoiceId_key" ON "PlatformSubscription"("initialInvoiceId");
CREATE UNIQUE INDEX "PlatformSubscription_userId_channel_key" ON "PlatformSubscription"("userId", "channel");
CREATE INDEX "PlatformSubscription_status_nextChargeAt_idx" ON "PlatformSubscription"("status", "nextChargeAt");

-- Действующие платные пользователи сохраняют все площадки при последующих продлениях.
UPDATE "User"
SET "legacyAllPlatforms" = true
WHERE "tariff" <> 'FREE' AND "tariffExpiresAt" > CURRENT_TIMESTAMP;

INSERT INTO "PlatformEntitlement" ("id", "userId", "channel", "tariff", "kind", "startsAt", "expiresAt", "autoRenew", "updatedAt")
SELECT concat('legacy_', "id", '_', lower(channel::text)), "id", channel, "tariff", 'LEGACY', CURRENT_TIMESTAMP, NULL, true, CURRENT_TIMESTAMP
FROM "User"
CROSS JOIN unnest(ARRAY['TELEGRAM'::"DeliveryChannel", 'VK'::"DeliveryChannel", 'MAX'::"DeliveryChannel"]) channel
WHERE "legacyAllPlatforms" = true
ON CONFLICT DO NOTHING;
