import { createHash } from "node:crypto";
import { Prisma } from "@/generated/prisma/client";
import { prisma } from "@/lib/prisma";

export const PREMIUM_TRIAL_DAYS = 10;
export const PREMIUM_TRIAL_PROMO_CODE = "DEMO10";

export type PremiumTrialSource = "WEB_BUTTON" | "PROMO_CODE" | "TELEGRAM" | "MAX" | "VK";

export function isPremiumTrialPromoCode(value: string | null | undefined): boolean {
  return value?.trim().toUpperCase() === PREMIUM_TRIAL_PROMO_CODE;
}

export async function grantPremiumTrial(userId: string, source: PremiumTrialSource) {
  const now = new Date();
  const current = await prisma.user.findUnique({
    where: { id: userId },
    select: { premiumTrialUsedAt: true, tariff: true, tariffExpiresAt: true },
  });

  if (!current || current.premiumTrialUsedAt) {
    return { granted: false as const, reason: "already-used" as const, expiresAt: null };
  }

  // Не заменяем действующую платную Premium-подписку пробным периодом.
  if (current.tariff === "PREMIUM" && current.tariffExpiresAt && current.tariffExpiresAt > now) {
    return { granted: false as const, reason: "premium-active" as const, expiresAt: current.tariffExpiresAt };
  }

  const expiresAt = new Date(now.getTime() + PREMIUM_TRIAL_DAYS * 24 * 60 * 60 * 1000);
  const updated = await prisma.user.updateMany({
    where: { id: userId, premiumTrialUsedAt: null },
    data: {
      premiumTrialStartedAt: now,
      premiumTrialExpiresAt: expiresAt,
      premiumTrialUsedAt: now,
      premiumTrialSource: source,
    },
  });

  if (updated.count === 1 && (source === "TELEGRAM" || source === "VK" || source === "MAX")) {
    await prisma.platformEntitlement.upsert({
      where: { userId_channel_kind: { userId, channel: source, kind: "TRIAL" } },
      create: { userId, channel: source, tariff: "PREMIUM", kind: "TRIAL", startsAt: now, expiresAt },
      update: { tariff: "PREMIUM", startsAt: now, expiresAt },
    });
  }

  return updated.count === 1
    ? { granted: true as const, reason: "activated" as const, expiresAt }
    : { granted: false as const, reason: "already-used" as const, expiresAt: null };
}

function hashPromoCode(code: string) {
  return createHash("sha256").update(code.trim().toUpperCase()).digest("hex");
}

export async function redeemPremiumPromoCode(userId: string, rawCode: string, channel: "TELEGRAM" | "VK" | "MAX" = "TELEGRAM") {
  const codeHash = hashPromoCode(rawCode);
  const now = new Date();
  const promo = await prisma.premiumPromoCode.findUnique({ where: { codeHash } });
  if (!promo) return { granted: false as const, reason: "invalid" as const, expiresAt: null };
  if (promo.redeemedAt || (promo.expiresAt && promo.expiresAt <= now)) {
    return { granted: false as const, reason: "already-used" as const, expiresAt: null };
  }

  try {
    return await prisma.$transaction(async (tx) => {
      const currentPromo = await tx.premiumPromoCode.findUnique({ where: { id: promo.id } });
      const current = await tx.user.findUnique({
        where: { id: userId },
        select: { tariff: true, tariffExpiresAt: true, premiumTrialExpiresAt: true },
      });
      if (!currentPromo || currentPromo.redeemedAt || (currentPromo.expiresAt && currentPromo.expiresAt <= now)) {
        return { granted: false as const, reason: "already-used" as const, expiresAt: null };
      }
      if (!current) return { granted: false as const, reason: "already-used" as const, expiresAt: null };
      if (current.tariff === "PREMIUM" && current.tariffExpiresAt && current.tariffExpiresAt.getUTCFullYear() === 9999) {
        return { granted: false as const, reason: "premium-active" as const, expiresAt: current.tariffExpiresAt };
      }

      const claimed = await tx.premiumPromoCode.updateMany({
        where: { id: currentPromo.id, redeemedAt: null, OR: [{ expiresAt: null }, { expiresAt: { gt: now } }] },
        data: { redeemedAt: now, redeemedById: userId },
      });
      if (claimed.count !== 1) return { granted: false as const, reason: "already-used" as const, expiresAt: null };

      const activeUntil = [current.tariffExpiresAt, current.premiumTrialExpiresAt]
        .filter((date): date is Date => Boolean(date && date > now))
        .sort((a, b) => b.getTime() - a.getTime())[0];
      const startsAt = activeUntil ?? now;
      const expiresAt = new Date(startsAt.getTime() + currentPromo.durationDays * 24 * 60 * 60 * 1000);
      await tx.user.update({ where: { id: userId }, data: { tariff: "PREMIUM", tariffExpiresAt: expiresAt } });
      await tx.platformEntitlement.upsert({
        where: { userId_channel_kind: { userId, channel, kind: "TRIAL" } },
        create: { userId, channel, tariff: "PREMIUM", kind: "TRIAL", startsAt, expiresAt },
        update: { tariff: "PREMIUM", startsAt, expiresAt },
      });
      return { granted: true as const, reason: "activated" as const, expiresAt };
    });
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002") {
      return { granted: false as const, reason: "already-used" as const, expiresAt: null };
    }
    throw error;
  }
}
