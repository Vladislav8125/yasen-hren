import type { DeliveryChannel, Tariff } from "@/generated/prisma/client";
import { prisma } from "@/lib/prisma";

// Единая точка проверки доступа — архитектурное ТЗ, раздел 4:
// "не «если tariff == PREMIUM» разбросано по коду, а один сервис
// core/access.ts, у которого один вход". Если условия тарифа изменятся —
// правится один файл, а не каждый экран по отдельности.

export type Feature =
  | "EXTENDED_CARD_CONTENT" // развёрнутое описание + инструкция на карте
  | "SECOND_CARD" // 2-я карта дня + выбор сферы
  | "MIRROR" // базовое «Зеркало» (топ-3 архетипа)
  | "MIRROR_FULL" // полное «Зеркало» (тренды по сферам)
  | "CONSULTATION"; // консультация с основателем, 1 раз/мес

const RULES: Record<Feature, Tariff[]> = {
  EXTENDED_CARD_CONTENT: ["STANDARD", "PREMIUM"],
  SECOND_CARD: ["PREMIUM"],
  MIRROR: ["STANDARD", "PREMIUM"],
  MIRROR_FULL: ["PREMIUM"],
  CONSULTATION: ["PREMIUM"],
};

export function canUserAccess(tariff: Tariff, feature: Feature): boolean {
  return RULES[feature].includes(tariff);
}

/**
 * Платный тариф без даты окончания или с истёкшей датой считается
 * невалидным — эффективно пользователь работает как Free, пока не
 * продлит подписку (проверка "на лету" при заходе, без отдельного крона
 * — архитектурное ТЗ, раздел 8).
 */
export function isTariffActive(user: { tariff: Tariff; tariffExpiresAt: Date | null }): boolean {
  if (user.tariff === "FREE") return true;
  if (!user.tariffExpiresAt) return false;
  return user.tariffExpiresAt.getTime() > Date.now();
}

export function effectiveTariff(user: {
  tariff: Tariff;
  tariffExpiresAt: Date | null;
  premiumTrialExpiresAt?: Date | null;
}): Tariff {
  if (user.premiumTrialExpiresAt && user.premiumTrialExpiresAt.getTime() > Date.now()) return "PREMIUM";
  return isTariffActive(user) ? user.tariff : "FREE";
}

type ChannelUser = Parameters<typeof effectiveTariff>[0] & {
  id: string;
  legacyAllPlatforms?: boolean;
};

/**
 * Площадочный доступ с совместимым резервом для старых пользователей.
 * Новые оплаты читаются из PlatformEntitlement; legacy-пользователям доступ
 * намеренно оставлен на всех каналах.
 */
export async function effectiveTariffForChannel(user: ChannelUser, channel: Exclude<DeliveryChannel, "WEB">): Promise<Tariff> {
  if (user.premiumTrialExpiresAt && user.premiumTrialExpiresAt > new Date()) {
    const trial = await prisma.platformEntitlement.findFirst({
      where: { userId: user.id, channel, kind: "TRIAL", OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }] },
      orderBy: { expiresAt: "desc" },
    });
    if (trial) return "PREMIUM";
  }
  if (user.legacyAllPlatforms) return effectiveTariff(user);
  const entitlement = await prisma.platformEntitlement.findFirst({
    where: { userId: user.id, channel, OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }] },
    orderBy: [{ tariff: "desc" }, { expiresAt: "desc" }],
  });
  if (entitlement) return entitlement.tariff;

  // Старый глобальный тариф разрешён на всех площадках только пользователям,
  // явно помеченным миграцией как исторические.
  return "FREE";
}

export async function canAccessWebKnowledge(user: ChannelUser): Promise<boolean> {
  if (user.legacyAllPlatforms && effectiveTariff(user) !== "FREE") return true;
  const count = await prisma.platformEntitlement.count({
    where: { userId: user.id, tariff: { in: ["STANDARD", "PREMIUM"] }, OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }] },
  });
  return count > 0 || effectiveTariff(user) !== "FREE";
}

export function proratedAddonAmountKopecks(expiresAt: Date, now = new Date()) {
  const remainingMs = Math.max(0, expiresAt.getTime() - now.getTime());
  return Math.max(100, Math.ceil((29_000 * remainingMs) / (30 * 24 * 60 * 60 * 1000)));
}
