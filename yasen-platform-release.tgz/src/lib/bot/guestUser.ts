import { randomUUID } from "node:crypto";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import type { DeliveryChannel } from "@/generated/prisma/client";

type BotChannel = Exclude<DeliveryChannel, "WEB">;

function platformWhere(channel: BotChannel, externalId: string) {
  if (channel === "TELEGRAM") return { telegramChatId: externalId };
  if (channel === "VK") return { vkUserId: externalId };
  return { maxUserId: externalId };
}

export async function getOrCreateBotUser(channel: BotChannel, externalId: string, displayName?: string) {
  const where = platformWhere(channel, externalId);
  const existing = await prisma.user.findUnique({ where });
  if (existing) return { user: existing, created: false };

  const passwordHash = await bcrypt.hash(randomUUID(), 10);
  const platformIdentity =
    channel === "TELEGRAM"
      ? { telegramChatId: externalId }
      : channel === "VK"
        ? { vkUserId: externalId }
        : { maxUserId: externalId };
  try {
    const user = await prisma.user.create({
      data: {
        email: `${channel.toLowerCase()}-${externalId}@guest.yasenhren.local`,
        name: displayName?.trim().slice(0, 120) || `Гость ${channel}`,
        passwordHash,
        preferredChannel: channel,
        isGuest: true,
        ...platformIdentity,
      },
    });
    return { user, created: true };
  } catch {
    const concurrent = await prisma.user.findUnique({ where });
    if (!concurrent) throw new Error(`Не удалось создать гостевой профиль ${channel}`);
    return { user: concurrent, created: false };
  }
}

export const BOT_WELCOME =
  "👋 Привет! Я — бот «Ясен Хрен».\n\nЗдесь можно каждый день получать карту и короткую подсказку к ней. Регистрация не нужна.\n\nНажми «🃏 Получить карту дня», чтобы начать. Подписка открывает дополнительные возможности, а физическую колоду можно заказать отдельно — без привязки к веб-базе знаний.";
