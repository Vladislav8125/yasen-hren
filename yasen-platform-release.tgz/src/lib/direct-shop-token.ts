import { createHmac, timingSafeEqual } from "node:crypto";

const TOKEN_TTL_MS = 24 * 60 * 60 * 1000;
export type DirectShopChannel = "telegram" | "vk" | "max";

function secret() {
  const value = process.env.AUTH_SECRET;
  if (!value) throw new Error("AUTH_SECRET не задан");
  return value;
}

function signature(payload: string) {
  return createHmac("sha256", secret()).update(payload).digest("hex").slice(0, 24);
}

export function createGuestDeckToken(channel: DirectShopChannel, externalId: string) {
  const payload = `${channel}.${externalId}.${Date.now() + TOKEN_TTL_MS}`;
  return Buffer.from(`${payload}.${signature(payload)}`).toString("base64url");
}

export function verifyGuestDeckToken(token: string): { channel: DirectShopChannel; externalId: string } | null {
  try {
    const decoded = Buffer.from(token, "base64url").toString("utf8");
    const [channel, externalId, expiresAt, provided] = decoded.split(".");
    if ((channel !== "telegram" && channel !== "vk" && channel !== "max") || !externalId || !expiresAt || !provided || Date.now() > Number(expiresAt)) return null;
    const expected = signature(`${channel}.${externalId}.${expiresAt}`);
    const left = Buffer.from(expected);
    const right = Buffer.from(provided);
    if (left.length !== right.length || !timingSafeEqual(left, right)) return null;
    return { channel, externalId };
  } catch {
    return null;
  }
}

export function deckSelectionUrl(baseUrl: string, channel: DirectShopChannel, externalId: string) {
  const token = createGuestDeckToken(channel, externalId);
  return `${baseUrl.replace(/\/$/, "")}/deck?source=${encodeURIComponent(token)}`;
}
