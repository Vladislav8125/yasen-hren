import { prisma } from "@/lib/prisma";
import { getShopProduct } from "@/lib/shop";
import { findPublicShopProduct, rub } from "@/lib/public-shop";
import { updateOrderStatus, updatePublicOrderStatus } from "./actions";

const STATUS_LABEL: Record<string, string> = {
  REQUESTED: "Запрошено",
  CONTACTED: "Связались",
  COMPLETED: "Выполнено",
  CANCELLED: "Отменено",
};

export default async function AdminShopPage() {
  const [orders, publicOrders] = await Promise.all([
    prisma.shopOrder.findMany({ orderBy: { createdAt: "desc" }, include: { user: true, psychologist: true } }),
    prisma.publicShopOrder.findMany({ orderBy: { createdAt: "desc" } }),
  ]);

  const active = orders.filter((o) => o.status === "REQUESTED" || o.status === "CONTACTED");
  const rest = orders.filter((o) => o.status === "COMPLETED" || o.status === "CANCELLED");

  return (
    <main className="p-6">
      <h1 className="font-display text-2xl text-parchment-hi mb-6">Заказы магазина</h1>

      <section className="mb-12 max-w-4xl">
        <h2 className="font-technical text-xs uppercase tracking-widest text-gold-bright mb-3">Заказы с публичной витрины</h2>
        {publicOrders.length === 0 ? <p className="font-body text-bone-dim">Пока нет заказов с сайта /shop.</p> : <div className="flex flex-col gap-3">{publicOrders.map((order) => {
          const product = findPublicShopProduct(order.product, order.variant ?? undefined);
          return <div key={order.id} className="rounded-lg border border-gold/50 bg-void-elevated p-4"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="font-display text-lg text-parchment-hi">{product?.title ?? order.product}</p><p className="mt-1 font-body text-sm text-bone-dim">{order.name} · {order.email} · {order.phone}</p><p className="mt-1 font-technical text-[10px] uppercase tracking-widest text-gold">{order.quantity} шт. · {rub(order.amount / 100)} · {order.createdAt.toLocaleString("ru-RU")}</p>{order.sourceChannel && <p className="mt-1 font-technical text-[10px] uppercase text-gold">Источник: {order.sourceChannel} · {order.sourceExternalId}</p>}{order.deliveryAddress && <p className="mt-2 font-body text-sm text-bone">Доставка: {order.deliveryMethod ?? "не указано"} · {order.deliveryAddress}</p>}{order.comment && <p className="mt-1 font-body text-sm text-bone-dim">Комментарий: {order.comment}</p>}{order.promoCode && <p className="mt-1 font-technical text-[10px] uppercase text-gold">Промокод: {order.promoCode}</p>}</div><form action={updatePublicOrderStatus} className="flex flex-wrap gap-2"><input type="hidden" name="id" value={order.id} /><select name="status" defaultValue={order.status} className="rounded border border-void-border bg-void px-2 py-1.5 font-technical text-xs text-bone"><option value="PENDING">Ожидает оплаты</option><option value="PAID">Оплачен</option><option value="FULFILLED">Выполнен</option><option value="CANCELLED">Отменён</option></select><button className="rounded border border-gold px-3 py-1.5 font-technical text-xs uppercase text-gold hover:bg-gold/10">Сохранить</button></form></div></div>;
        })}</div>}
      </section>

      {active.length === 0 ? (
        <p className="font-body text-bone-dim mb-8">Активных заказов нет.</p>
      ) : (
        <div className="flex flex-col gap-4 max-w-2xl mb-10">
          {active.map((o) => (
            <div key={o.id} className="rounded-lg border border-gold bg-void-elevated p-4">
              <p className="font-display text-lg text-gold-bright">{getShopProduct(o.product).title}</p>
              <p className="font-technical text-xs text-bone-dim mb-3">
                {o.user.name} · {o.user.email} · {o.createdAt.toLocaleDateString("ru-RU")}
                {o.psychologist && ` · к ${o.psychologist.name}`}
              </p>
              <form action={updateOrderStatus} className="flex flex-wrap gap-2">
                <input type="hidden" name="id" value={o.id} />
                <label className="flex items-center gap-2 font-technical text-xs text-bone-dim">Оплата, ₽<input name="amountRub" type="number" min="0" step="1" defaultValue={o.amount ? o.amount / 100 : getShopProduct(o.product).priceRub} className="w-28 rounded border border-void-border bg-void px-2 py-1 text-bone" /></label>
                <button
                  type="submit"
                  name="status"
                  value="CONTACTED"
                  className="rounded bg-red-primary px-3 py-1.5 font-technical text-xs uppercase text-parchment hover:bg-red-primary-dark"
                >
                  Связались
                </button>
                <button
                  type="submit"
                  name="status"
                  value="COMPLETED"
                  className="rounded border border-void-border px-3 py-1.5 font-technical text-xs uppercase text-bone-dim hover:text-gold-bright"
                >
                  Выполнено
                </button>
                <button
                  type="submit"
                  name="status"
                  value="CANCELLED"
                  className="rounded border border-void-border px-3 py-1.5 font-technical text-xs uppercase text-bone-dim hover:text-red-warning"
                >
                  Отменить
                </button>
              </form>
            </div>
          ))}
        </div>
      )}

      {rest.length > 0 && (
        <>
          <h2 className="font-technical text-xs uppercase tracking-widest text-gold-bright mb-3">История</h2>
          <div className="flex flex-col gap-2 max-w-2xl">
            {rest.map((o) => (
              <div
                key={o.id}
                className="flex items-center justify-between rounded border border-void-border px-4 py-2 font-body text-sm text-bone"
              >
                <span>
                  {getShopProduct(o.product).title} · {o.user.name}
                </span>
                <span className="text-bone-dim font-technical text-xs uppercase">{STATUS_LABEL[o.status]}</span>
              </div>
            ))}
          </div>
        </>
      )}
    </main>
  );
}
