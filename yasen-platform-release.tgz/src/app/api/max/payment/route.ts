import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { createRobokassaPayment } from "@/lib/robokassa";
import { verifyMaxLinkToken } from "@/lib/maxLink";
import type { Tariff } from "@/generated/prisma/client";

const PAID_TARIFFS = new Set<Tariff>(["STANDARD", "PREMIUM"]);
const appUrl = () => (process.env.APP_URL ?? "https://yasenhren.ru").replace(/\/$/, "");

export async function GET(request: Request) {
  const params = new URL(request.url).searchParams;
  const userId = verifyMaxLinkToken(params.get("token") ?? "");
  const tariff = params.get("tariff") as Tariff | null;
  if (!userId || !tariff || !PAID_TARIFFS.has(tariff)) return NextResponse.redirect(`${appUrl()}/tariffs?payment=invalid`);

  const user = await prisma.user.findUnique({ where: { id: userId }, select: { id: true } });
  if (!user) return NextResponse.redirect(`${appUrl()}/tariffs?payment=invalid`);

  try {
    return NextResponse.redirect(await createRobokassaPayment({ userId, tariff, channel: "MAX" }));
  } catch (error) {
    console.error("[max-payment] Robokassa payment could not be created", error);
    return NextResponse.redirect(`${appUrl()}/tariffs?payment=unavailable`);
  }
}
