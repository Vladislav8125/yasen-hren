import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { prisma } from "@/lib/prisma";
import { createRobokassaShopPayment, isRobokassaConfigured } from "@/lib/robokassa";
import { InvalidPublicShopPromoCodeError, resolvePublicShopPricing } from "@/lib/public-shop-pricing";
import { verifyGuestDeckToken } from "@/lib/direct-shop-token";

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  const productId = typeof body?.productId === "string" ? body.productId : "";
  const variant = typeof body?.variant === "string" ? body.variant : undefined;
  const name = typeof body?.name === "string" ? body.name.trim().slice(0, 120) : "";
  const email = typeof body?.email === "string" ? body.email.trim().toLowerCase().slice(0, 160) : "";
  const phone = typeof body?.phone === "string" ? body.phone.trim().slice(0, 40) : "";
  const deliveryAddress = typeof body?.deliveryAddress === "string" ? body.deliveryAddress.trim().slice(0, 500) : "";
  const deliveryMethod = typeof body?.deliveryMethod === "string" ? body.deliveryMethod.trim().slice(0, 40) : "";
  const source = typeof body?.source === "string" ? verifyGuestDeckToken(body.source) : null;
  const comment = typeof body?.comment === "string" ? body.comment.trim().slice(0, 1000) : "";
  const promoCode = typeof body?.promoCode === "string" ? body.promoCode.trim().toUpperCase().slice(0, 32) : "";
  const quantity = Math.max(1, Math.min(10, Number(body?.quantity) || 1));
  const personalDataConsent = body?.personalDataConsent === true;

  if (!name || !EMAIL.test(email) || !phone) {
    return NextResponse.json({ error: "Заполните товар, имя, корректный email и телефон" }, { status: 400 });
  }
  if (!personalDataConsent) {
    return NextResponse.json({ error: "Подтвердите согласие на обработку персональных данных" }, { status: 400 });
  }
  const referralCode = (await cookies()).get("yh_ref")?.value ?? "";
  let pricing;
  try {
    pricing = await resolvePublicShopPricing({ productId, variant, promoCode, referralCode });
  } catch (error) {
    if (error instanceof InvalidPublicShopPromoCodeError) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }
    if (error instanceof Error && error.message === "Товар не найден") {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }
    throw error;
  }
  const { product } = pricing;
  if (product.requiresDelivery && !deliveryAddress) {
    return NextResponse.json({ error: "Укажите адрес доставки" }, { status: 400 });
  }
  if (product.requiresDelivery && !["CDEK", "RUSSIAN_POST", "COURIER"].includes(deliveryMethod)) {
    return NextResponse.json({ error: "Выберите способ доставки" }, { status: 400 });
  }
  if (!isRobokassaConfigured()) {
    return NextResponse.json({ error: "Оплата временно недоступна. Заказ не создан — попробуйте позже или свяжитесь с поддержкой." }, { status: 503 });
  }

  // Стоимость намеренно рассчитывается на сервере: браузер не может изменить сумму заказа.
  const order = await prisma.publicShopOrder.create({
    data: {
      product: product.id,
      variant: product.variant ?? null,
      amount: pricing.unitPriceRub * 100 * quantity,
      quantity,
      name,
      email,
      phone,
      deliveryAddress: deliveryAddress || null,
      comment: comment || null,
      promoCode: promoCode || null,
      partnerId: pricing.partnerId,
      attributionSource: pricing.attributionSource,
      sourceChannel: source ? ({ telegram: "TELEGRAM", vk: "VK", max: "MAX" } as const)[source.channel] : null,
      sourceExternalId: source?.externalId ?? null,
      deliveryMethod: deliveryMethod || null,
      personalDataConsentAt: new Date(),
      personalDataConsentVersion: "2026-08-31",
    },
  });

  let paymentUrl: string;
  try {
    paymentUrl = await createRobokassaShopPayment({ orderId: order.id, amount: order.amount, description: `Ясен Хрен — ${product.title}` });
  } catch (error) {
    await prisma.publicShopOrder.delete({ where: { id: order.id } }).catch(() => undefined);
    console.error("Public shop payment link creation failed", error);
    return NextResponse.json({ error: "Не удалось создать платёжную ссылку. Заказ не оформлен — попробуйте позже." }, { status: 503 });
  }
  return NextResponse.json({ ok: true, orderId: order.id, paymentUrl });
}
