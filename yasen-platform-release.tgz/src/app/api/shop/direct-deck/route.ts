import { NextResponse } from "next/server";
import { verifyMaxLinkToken } from "@/lib/maxLink";
import { verifyTelegramLinkToken } from "@/lib/telegramLink";
import { verifyGuestDeckToken } from "@/lib/direct-shop-token";

const appUrl = () => (process.env.APP_URL ?? "https://yasenhren.ru").replace(/\/$/, "");

export async function GET(request: Request) {
  const params = new URL(request.url).searchParams;
  const token = params.get("token") ?? "";
  const linkedUserId = (token && verifyTelegramLinkToken(token)) || (token && verifyMaxLinkToken(token));
  const guest = !linkedUserId && token ? verifyGuestDeckToken(token) : null;
  const target = guest ? `${appUrl()}/deck?source=${encodeURIComponent(token)}` : `${appUrl()}/deck`;
  return NextResponse.redirect(target);
}
