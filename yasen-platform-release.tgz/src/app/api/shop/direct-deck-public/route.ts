import { NextResponse } from "next/server";
const appUrl = () => (process.env.APP_URL ?? "https://yasenhren.ru").replace(/\/$/, "");

export async function GET() {
  return NextResponse.redirect(`${appUrl()}/deck`);
}
