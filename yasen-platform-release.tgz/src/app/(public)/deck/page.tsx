import Link from "next/link";
import { findPublicShopProduct } from "@/lib/public-shop";
import { verifyGuestDeckToken } from "@/lib/direct-shop-token";

const rub = (value: number) => `${new Intl.NumberFormat("ru-RU").format(value)} ₽`;

export default async function DeckSelectionPage({ searchParams }: { searchParams: Promise<{ source?: string }> }) {
  const params = await searchParams;
  const source = params.source && verifyGuestDeckToken(params.source) ? params.source : "";
  const variants = ["GLOSS", "SOFT_TOUCH"] as const;

  return (
    <main className="mx-auto w-full max-w-5xl px-6 py-14 md:py-20">
      <p className="font-technical text-xs uppercase tracking-widest text-gold">Физическая колода</p>
      <h1 className="mt-3 font-display text-4xl text-parchment-hi md:text-5xl">Выберите покрытие</h1>
      <p className="mt-4 max-w-2xl font-body text-bone-dim">Одна и та же полная колода «Ясен Хрен» в двух вариантах исполнения. Регистрация и подписка на приложение не нужны.</p>
      <div className="mt-10 grid gap-6 md:grid-cols-2">
        {variants.map((variant) => {
          const product = findPublicShopProduct("CARDS", variant)!;
          const query = new URLSearchParams({ product: "CARDS", variant });
          if (source) query.set("source", source);
          return (
            <article key={variant} className="flex flex-col rounded-2xl border border-gold/40 bg-void-elevated p-7">
              <p className="font-technical text-xs uppercase tracking-widest text-gold">{variant === "GLOSS" ? "Глянец" : "Софт-тач"}</p>
              <h2 className="mt-3 font-display text-2xl text-parchment-hi">{product.title}</h2>
              <p className="mt-3 font-display text-3xl text-red-primary">{rub(product.priceRub)}</p>
              <p className="mt-4 flex-1 font-body leading-relaxed text-bone-dim">{product.shortDescription}</p>
              <Link href={`/shop/checkout?${query.toString()}`} className="mt-7 rounded bg-red-primary px-5 py-3 text-center font-technical text-xs uppercase tracking-widest text-parchment hover:bg-red-primary-dark">Выбрать и оформить</Link>
            </article>
          );
        })}
      </div>
    </main>
  );
}
