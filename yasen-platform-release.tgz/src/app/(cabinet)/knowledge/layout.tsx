import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { canAccessWebKnowledge } from "@/lib/access";

export default async function KnowledgeAccessLayout({ children }: { children: React.ReactNode }) {
  const session = await auth();
  if (!session?.user) redirect("/login");
  const user = await prisma.user.findUniqueOrThrow({ where: { id: session.user.id } });
  if (!(await canAccessWebKnowledge(user))) redirect("/tariffs?knowledge=paid");
  return children;
}
