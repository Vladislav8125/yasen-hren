"use server";

import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { createRobokassaPayment } from "@/lib/robokassa";
import type { DeliveryChannel, Tariff } from "@/generated/prisma/client";
import { resolvePromoPartner, setAttribution } from "@/lib/partners";
import { grantPremiumTrial, isPremiumTrialPromoCode, redeemPremiumPromoCode } from "@/lib/premium-trial";
import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";
import { proratedAddonAmountKopecks } from "@/lib/access";

export async function subscribeToTariff(formData: FormData) {
  const session = await auth();
  if (!session?.user) redirect("/login");

  const tariff = formData.get("tariff") as Tariff;
  const requestedChannel = formData.get("channel") as DeliveryChannel;
  const channel: "TELEGRAM" | "VK" | "MAX" = requestedChannel === "VK" || requestedChannel === "MAX" ? requestedChannel : "TELEGRAM";
  const promoCode = String(formData.get("promoCode") ?? "");
  const partner = await resolvePromoPartner(promoCode);
  if (partner) await setAttribution({ userId: session.user.id, partnerId: partner.id, source: "promo" });
  const confirmationUrl = await createRobokassaPayment({ userId: session.user.id, tariff, channel });

  redirect(confirmationUrl);
}

export async function subscribeToAddon(formData: FormData) {
  const session = await auth();
  if (!session?.user) redirect("/login");
  const channel = formData.get("channel") as DeliveryChannel;
  if (!( ["TELEGRAM", "VK", "MAX"] as DeliveryChannel[]).includes(channel)) redirect("/tariffs?addon=invalid");
  const primary = await prisma.platformEntitlement.findFirst({
    where: { userId: session.user.id, kind: "PRIMARY", expiresAt: { gt: new Date() } },
    orderBy: { expiresAt: "desc" },
  });
  if (!primary?.expiresAt || primary.channel === channel) redirect("/tariffs?addon=invalid");
  const amountKopecks = proratedAddonAmountKopecks(primary.expiresAt);
  const confirmationUrl = await createRobokassaPayment({
    userId: session.user.id,
    tariff: primary.tariff,
    channel,
    purpose: "PLATFORM_ADDON",
    amountKopecks,
    accessExpiresAt: primary.expiresAt,
  });
  redirect(confirmationUrl);
}

export async function startPremiumTrial(formData: FormData) {
  const session = await auth();
  if (!session?.user) redirect("/login");

  const promoCode = String(formData.get("promoCode") ?? "").trim();
  const requestedChannel = formData.get("channel") as DeliveryChannel;
  const channel: "TELEGRAM" | "VK" | "MAX" = requestedChannel === "VK" || requestedChannel === "MAX" ? requestedChannel : "TELEGRAM";
  if (promoCode && !isPremiumTrialPromoCode(promoCode)) {
    const result = await redeemPremiumPromoCode(session.user.id, promoCode, channel);
    revalidatePath("/tariffs");
    revalidatePath("/profile");
    const status = result.granted ? "promo-activated" : result.reason === "already-used" ? "promo-used" : result.reason;
    redirect(`/tariffs?trial=${status}`);
  }

  const result = await grantPremiumTrial(session.user.id, channel);
  revalidatePath("/tariffs");
  revalidatePath("/profile");
  redirect(`/tariffs?trial=${result.granted ? "activated" : result.reason}`);
}
