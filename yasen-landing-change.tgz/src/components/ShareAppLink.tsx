"use client";

import { useState } from "react";

const landingUrl = "https://yasenhren.ru/";

export function ShareAppLink() {
  const [copied, setCopied] = useState(false);

  async function share() {
    const shareData = {
      title: "Ясен Хрен",
      text: "Попробуй приложение «Ясен Хрен» — игра психологической гигиены.",
      url: landingUrl,
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
        return;
      }

      await navigator.clipboard.writeText(landingUrl);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2500);
    } catch (error) {
      if ((error as DOMException).name !== "AbortError") {
        await navigator.clipboard.writeText(landingUrl);
        setCopied(true);
        window.setTimeout(() => setCopied(false), 2500);
      }
    }
  }

  return (
    <button type="button" onClick={share} className="rounded border border-red-primary bg-red-primary px-3 py-2 font-technical text-[10px] uppercase tracking-widest text-[#fff8e6] shadow-sm transition-colors hover:bg-red-primary-dark">
      {copied ? "Ссылка скопирована" : "Поделиться с другом"}
    </button>
  );
}
