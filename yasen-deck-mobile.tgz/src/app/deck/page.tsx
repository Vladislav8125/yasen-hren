import { Suspense } from "react";
import { PublicShopCheckout } from "@/components/PublicShopCheckout";

export default function DeckPage() {
  return (
    <Suspense
      fallback={
        <main className="mx-auto max-w-lg px-4 py-6 font-body text-bone-dim">
          Загружаем оформление…
        </main>
      }
    >
      <PublicShopCheckout deckMode />
    </Suspense>
  );
}
