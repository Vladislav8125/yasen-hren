import { NextResponse } from "next/server";

export function GET() {
  const response = NextResponse.redirect("https://yasenhren.ru/", 307);
  response.headers.set("Cache-Control", "no-store, no-cache, must-revalidate");
  return response;
}
