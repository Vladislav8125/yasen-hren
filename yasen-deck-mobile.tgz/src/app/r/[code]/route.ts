import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  codeFromText,
  resolveLinkPartner,
  setAttribution,
} from "@/lib/partners";
import { auth } from "@/auth";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ code: string }> },
) {
  const { code } = await params;
  const normalized = codeFromText(code);
  const session = await auth();
  const partner = await resolveLinkPartner(normalized);
  // За Nginx request.url содержит внутренний адрес (localhost:3000).
  // Для редиректа посетителю нужен публичный адрес приложения.
  const product = new URL(request.url).searchParams.get("product") ?? "";
  const productTargets: Record<string, string> = {
    "cards-gloss": "/shop/checkout?product=CARDS&variant=GLOSS",
    "cards-soft-touch": "/shop/checkout?product=CARDS&variant=SOFT_TOUCH",
    founder: "/shop/checkout?product=FOUNDER",
    // Платформа требует аккаунт для оплаты, поэтому после ссылки человек
    // сразу попадает на регистрацию с выбранным тарифом.
    "platform-free": "/register?tariff=FREE",
    "platform-standard": "/register?tariff=STANDARD",
    "platform-premium": "/register?tariff=PREMIUM",
  };
  const configuredOrigin = new URL(
    process.env.APP_URL ?? "https://yasenhren.ru",
  );
  const appOrigin =
    configuredOrigin.hostname === "localhost"
      ? "https://yasenhren.ru"
      : configuredOrigin.origin;
  const target = new URL(productTargets[product] ?? "/", appOrigin);
  const response = NextResponse.redirect(target);
  if (!partner) return response;
  if (session?.user?.id === partner.userId) return response;

  await prisma.referralClick.create({
    data: {
      partnerId: partner.id,
      targetPath: `${target.pathname}${target.search}`,
      referer: request.headers.get("referer")?.slice(0, 500) ?? null,
    },
  });
  // Для уже авторизованного покупателя последний переход меняет привязку сразу.
  if (session?.user?.id)
    await setAttribution({
      userId: session.user.id,
      partnerId: partner.id,
      source: "link",
    });
  response.cookies.set("yh_ref", normalized, {
    // Cookie хранит привязку гостевого заказа длительно; после регистрации
    // бессрочная атрибуция дополнительно сохраняется в базе.
    maxAge: 10 * 365 * 24 * 60 * 60,
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
  });
  return response;
}
